chrome.omnibox.onInputEntered.addListener(function(text){
    console.log(text);
});